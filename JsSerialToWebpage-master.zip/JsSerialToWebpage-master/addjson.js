const data = [
  {
    name: 'John',
    surname: 'Snow',
    age: 26,
    gender: 'M'
  },
  {
    name: 'Clair',
    surname: 'White',
    age: 33,
    gender: 'F'
  },
  {
    name: 'Fancy',
    surname: 'Brown',
    age: 78,
    gender: 'F'
  }
];

data.push({ name: 'Clair', surname: 'White', age: 33, gender: 'F' });
console.log(data[3]);
